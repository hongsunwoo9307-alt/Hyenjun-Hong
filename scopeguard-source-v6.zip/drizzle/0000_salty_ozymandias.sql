CREATE TABLE `scopeguard_records` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`kind` text NOT NULL,
	`payload` text NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `scopeguard_owner_kind` ON `scopeguard_records` (`owner`,`kind`);