import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';

const source=readFileSync(new URL('./public/app.js',import.meta.url),'utf8')
 .replace(/^import .*?;\r?\n/,'').replace(/\r?\ninit\(\);\s*$/,'');
function screen(response){
 const nodes=new Map();
 const element=id=>{
  if(!nodes.has(id))nodes.set(id,{textContent:'',hidden:id==='service-error',disabled:false,style:{},classList:{toggle(){}},value:''});
  return nodes.get(id);
 };
 const context=vm.createContext({
  document:{getElementById:element,querySelectorAll:()=>[]},
  fetch:async()=>Response.json(response),setTimeout:()=>1,clearTimeout(){},
  console
 });
 element('analysis-mode').value='ai';
 vm.runInContext(source,context);
 vm.runInContext("connectionConfig={server:true,storage:true,ai:true,paypal:false};server=true;aiReady=true;renderConnections()",context);
 return {context,element,run:script=>vm.runInContext(script,context)};
}
const creditError="showError(Object.assign(Error('Add API credits, then retry.'),{code:'ai_credits_exhausted'}))";

test('approving a historical AI result never claims a fresh AI response',async()=>{
 for(const route of ['/api/demo-approve','/api/demo-change']){
  const app=screen({analysis:'openai',status:'demo-approved'});
  await app.run('api('+JSON.stringify(route)+',{})');
  assert.equal(app.element('mode').textContent,'● AI configured');
  assert.doesNotMatch(app.element('connections').textContent,/response verified/);
 }
});

test('an unrelated action failure preserves the AI billing guidance',async()=>{
 const app=screen({});
 app.run(creditError);
 await app.run("busy(document.getElementById('approve'),async()=>{throw Error('Payment unavailable')})");
 assert.equal(app.element('service-error').hidden,false);
 assert.equal(app.element('service-message').textContent,'Add API credits, then retry.');
 assert.equal(app.element('service-help').href,'https://platform.openai.com/settings/organization/billing');
 assert.equal(app.element('mode').textContent,'● AI needs attention');
});

test('only a successful current AI analysis clears the guidance and verifies the response',async()=>{
 for(const route of ['/api/quote','/api/change']){
  const app=screen({analysis:'openai'});
  app.run(creditError);
  await app.run('api('+JSON.stringify(route)+',{})');
  assert.equal(app.element('service-error').hidden,true);
  assert.equal(app.element('mode').textContent,'● AI response verified');
  assert.match(app.element('notice-detail').textContent,/AI analysis succeeded in this session/);
 }
});


test('rules selection hides but preserves an AI error until a fresh AI success',()=>{
 const app=screen({});app.run(creditError);
 app.element('analysis-mode').value='rules';app.run('renderConnections()');
 assert.equal(app.element('service-error').hidden,true);
 assert.equal(app.element('mode').textContent,'● Rule-based demo');
 app.element('analysis-mode').value='ai';app.run('renderConnections()');
 assert.equal(app.element('service-error').hidden,false);
 assert.equal(app.element('service-message').textContent,'Add API credits, then retry.');
});

test('a fresh Gemini response verifies AI and clears prior guidance',async()=>{
 const app=screen({analysis:'gemini'});app.run(creditError);
 app.run("connectionConfig.aiProvider='gemini'");await app.run("api('/api/quote',{})");
 assert.equal(app.element('service-error').hidden,true);
 assert.equal(app.element('mode').textContent,'● AI response verified');
 assert.match(app.element('connections').textContent,/Gemini: response verified/);
});
