export function money(cents){return new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(cents/100)}
export function rate(value){const n=Number(value);if(!Number.isFinite(n)||n<0||n>100000)throw Error('Rates must be between $0 and $100,000.');return Math.round(n*100)}
export function makeQuote(input){
 const brief=String(input.brief||'').trim();if(brief.length<15||brief.length>8000)throw Error('Please enter a brief between 15 and 8,000 characters.');
 const rates={base:rate(input.rates.base),captions:rate(input.rates.captions),music:rate(input.rates.music)};if(rates.base<100)throw Error('Set a main video rate of at least $1.');
 const duration=brief.match(/(\d+)\s*[- ]?(?:seconds?|secs?|초)/i)?.[1];
 const revision=brief.match(/(\d+)\s*(?:rounds?|회|차)[^.!\n]{0,20}(?:revision|수정)/i)?.[1]||brief.match(/(?:수정|revisions?)\s*(\d+)/i)?.[1]||(/two rounds/i.test(brief)?'2':null);
 const days=brief.match(/(?:within\s*)?(\d+)\s*(?:days?|일)/i)?.[1];
 const aspect=brief.match(/(?:16:9|9:16|1:1)/)?.[0]||null;
 const caption=/caption|subtitle|자막/i.test(brief), music=/music|bgm|음악|음원/i.test(brief);
 const langs=[];if(/english|영어|영문/i.test(brief))langs.push('English');if(/korean|한국어|한글|국문/i.test(brief))langs.push('Korean');
 const items=[{label:`1 × ${duration?duration+'-second ':''}edited video${aspect?' · '+aspect:''}`,cents:rates.base}];
 if(caption)items.push({label:`${langs.length?langs.join(' + ')+' ':''}captions`,cents:rates.captions});
 if(music)items.push({label:'Background music selection (licensing costs excluded)',cents:rates.music});
 const assumptions=['Additional formats, languages and deliverables require separate approval. Music licensing, taxes and third-party costs are excluded.'];
 if(!revision)assumptions.push('Revision limit not found: confirm with the client.');if(!days)assumptions.push('Delivery deadline not found: confirm with the client.');if(!aspect)assumptions.push('Aspect ratio not found: confirm with the client.');
 return {id:globalThis.crypto?.randomUUID?.() || `demo-${Date.now()}-${Math.random().toString(36).slice(2)}`,project:String(input.project||'Untitled project').slice(0,100),client:String(input.client||'Client').slice(0,100),brief,items,rates,total:items.reduce((s,i)=>s+i.cents,0),revisions:revision?Number(revision):null,days:days?Number(days):null,aspect,languages:langs,caption,music,assumptions,analysis:'demo-rules',status:'draft'};
}
export function compareChange(quote,text){
 if(!String(text).trim()||text.length>4000)throw Error('Enter a change request of up to 4,000 characters.');
 const items=[],ask=[];let recognized=false;
 for(const aspect of ['16:9','9:16','1:1'])if(text.includes(aspect)){recognized=true;if(aspect!==quote.aspect)items.push({label:`Additional ${aspect} video version`,cents:Math.round(quote.rates.base*.3),reason:'This format is outside the original deliverables.'})}
 for(const [pattern,lang] of [[/korean|한국어|한글|국문/i,'Korean'],[/english|영어|영문/i,'English']])if(pattern.test(text)){recognized=true;if(!quote.caption||!quote.languages.includes(lang))items.push({label:`Additional ${lang} captions`,cents:quote.rates.captions,reason:'This caption language is outside the agreement.'})}
 if(/tomorrow|오늘|내일|rush|urgent|긴급/i.test(text)){recognized=true;ask.push('Confirm the exact new deadline before accepting a rush fee.');items.push({label:'Proposed rush delivery surcharge',cents:Math.round(quote.rates.base*.25),reason:'Suggested surcharge only; the client must approve the new deadline and fee.'})}
 if(/extra.*revision|additional.*revision|수정.*추가|추가.*수정/i.test(text)){recognized=true;items.push({label:'Proposed additional revision round',cents:Math.round(quote.rates.base*.15),reason:'Confirm whether the original revision allowance has been exhausted.'})}
 if(!recognized)ask.push('This request could not be classified reliably. Review it manually; no price is inferred.');
 if(recognized&&!items.length)ask.push('Recognized formats/languages match the scope. This does not confirm that every detail is included.');
 return {items,questions:ask,total:items.reduce((s,i)=>s+i.cents,0),analysis:'demo-rules',request:text};
}
