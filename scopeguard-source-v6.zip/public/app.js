import {makeQuote,compareChange,money} from './domain.js';
const $=id=>document.getElementById(id);let quote=null,change=null,live=false,server=false,aiReady=false,toastTimer;let saving=false;let connectionConfig=null,aiState="configured",paypalState="configured",aiError=null;
const toast=s=>{$('toast').textContent=s;$('toast').style.display='block';clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').style.display='none',4500)};
function persist(){refreshProjects();try{localStorage.setItem('scopeguard-v1',JSON.stringify({quote,change}))}catch{toast('Browser storage unavailable; keep this tab open.')}}
function node(tag,text,cls){const el=document.createElement(tag);el.textContent=text;if(cls)el.className=cls;return el}
function view(name){for(const v of ['builder','how'])$(v).hidden=v!==name;document.querySelectorAll('.nav').forEach(n=>n.classList.toggle('active',n.dataset.view===name))}
document.querySelectorAll('.nav').forEach(n=>n.onclick=()=>view(n.dataset.view));$('back').onclick=()=>view('builder');
const approvalComplete=q=>q?.status==='paid'||(q?.status==='demo-approved'&&!live);
function render(){
 $('quote-empty').hidden=!!quote;$('quote-content').hidden=!quote;$('change-locked').hidden=['paid','demo-approved'].includes(quote?.status);$('change-form').hidden=!['paid','demo-approved'].includes(quote?.status);
 $('step2').classList.toggle('current',!!quote);$('step3').classList.toggle('current',['paid','demo-approved'].includes(quote?.status));
 if(!quote)return;
 $('quote-analysis').textContent=analysisLabel(quote.analysis);$('quote-project').textContent=quote.project;$('quote-client').textContent='Prepared for '+quote.client;$('quote-id').textContent='SG–'+quote.id.slice(-6).toUpperCase();
 const list=$('deliverables');list.replaceChildren();for(const item of quote.items){const li=node('li','');li.append(node('span',item.label),node('b',money(item.cents)));list.append(li)}
 $('revisions').textContent=quote.revisions??'Needs confirmation';$('timeline').textContent=quote.days?quote.days+' days after approval':'Needs confirmation';$('assumptions').textContent=quote.assumptions.join(' ');$('total').textContent=money(quote.total);
 const paid=approvalComplete(quote);$('quote-status').textContent=paid?(quote.status==='paid'?'SANDBOX PAID':'DEMO APPROVED'):'DRAFT';$('quote-status').classList.toggle('paid',paid);$('consent').disabled=paid;$('consent').checked=paid;$('approve').disabled=true;$('approve').textContent=paid?(quote.status==='paid'?'Sandbox payment captured ✓':'Demo approval saved ✓'):(live?'Approve & open PayPal Sandbox →':'Approve in demo mode →');
 $('approval-note').textContent=paid?(quote.status==='paid'?'Sandbox payment captured. No real money moved.':'Demo approval only. No payment was created.'):'Review the scope with your client before approving.';
 $('change-result').hidden=!change;if(change)renderChange();
}
const isAiResult=value=>['openai','gemini'].includes(value);
const analysisLabel=value=>value==='gemini'?'Analyzed with Gemini':value==='openai'?'Analyzed with OpenAI':'Rule-based demo · no AI call';
const analysisMode=()=>$('analysis-mode').value==='ai'?'ai':'rules';
$('analysis-mode').onchange=()=>renderConnections();
function ensureMode(){if(analysisMode()==='ai'&&!aiReady)throw Object.assign(Error('AI is not connected yet. Select the rules demo or finish the AI connection.'),{code:'ai_not_configured'})}
function readInput(){return{analysisMode:analysisMode(),project:$('project').value,client:$('client').value,brief:$('brief').value,rates:{base:$('base-rate').value,captions:$('caption-rate').value,music:$('music-rate').value}}}
async function api(path,data){const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const out=await r.json();if(!r.ok)throw Object.assign(Error(out.error||'Request failed.'),{code:out.code});if(['/api/quote','/api/change'].includes(path)&&isAiResult(out.analysis)){aiState='response verified';aiError=null;$('service-error').hidden=true;renderConnections()}return out}
async function busy(button,fn){if(saving)return;saving=true;$('analysis-mode').disabled=true;const old=button.textContent;button.disabled=true;button.textContent='Working…';try{await fn()}catch(e){showError(e)}finally{saving=false;$('analysis-mode').disabled=false;button.disabled=false;button.textContent=old;render()}}
$('analyze').onclick=()=>busy($('analyze'),async()=>{ensureMode();const input=readInput();quote=server?await api('/api/quote',input):makeQuote(input);change=null;persist();toast(isAiResult(quote.analysis)?'AI proposal generated. Review all details.':'Rule-based proposal generated. Review all details.')});
$('consent').onchange=()=>{$('approve').disabled=!$('consent').checked||approvalComplete(quote)};
$('approve').onclick=()=>busy($('approve'),async()=>{if(!quote||!$('consent').checked)return;if(live){const order=await api('/api/orders',{quoteId:quote.id,kind:'base'});location.assign(order.approvalUrl);return}if(server)quote=await api('/api/demo-approve',{quoteId:quote.id});else{quote.status='demo-approved';quote.approvedAt=new Date().toISOString()}persist();toast('Demo approval saved. No payment was created.')});
$('compare').onclick=()=>busy($('compare'),async()=>{ensureMode();if(!['paid','demo-approved'].includes(quote?.status))throw Error('Approve the proposal first.');change=server?await api('/api/change',{quoteId:quote.id,text:$('change').value,analysisMode:analysisMode()}):compareChange(quote,$('change').value);persist()});
function renderChange(){const root=$('change-result');root.hidden=false;root.replaceChildren();root.append(node('p',analysisLabel(change.analysis),'analysis-label'));root.append(node('div',change.items.length?'Scope change detected — proposed extras need approval.':'Manual review recommended',change.items.length?'change-alert':'change-alert clear'));const list=node('ul','','change-lines');for(const i of change.items){const li=node('li','');const copy=node('div',i.label);copy.title=i.reason;li.append(copy,node('b',money(i.cents)));list.append(li)}root.append(list);for(const q of change.questions||[])root.append(node('p',q,'micro'));if(change.items.length){const actions=node('div','','change-actions');actions.append(node('span','Proposed additional fee'),node('strong',money(change.total)));const b=node('button',approvalComplete(change)?(change.status==='paid'?'Sandbox change payment captured ✓':'Demo change approved ✓'):(live?'Approve & pay extra (Sandbox) →':'Approve extra in demo mode →'),'button primary');b.disabled=approvalComplete(change);b.onclick=()=>busy(b,async()=>{if(live){const order=await api('/api/orders',{quoteId:quote.id,kind:'change',changeId:change.id});location.assign(order.approvalUrl);return}if(server)change=await api('/api/demo-change',{changeId:change.id});else change.status='demo-approved';persist();toast('Demo change approved. No payment was created.')});actions.append(b);root.append(actions)}}
$('export').onclick=()=>{if(!quote)return;const text=`SCOPEGUARD — PROJECT PROPOSAL\n${quote.project}\nPrepared for: ${quote.client}\n\nDELIVERABLES\n${quote.items.map(i=>i.label+' — '+money(i.cents)).join('\n')}\n\nRevisions: ${quote.revisions??'To be agreed'}\nDelivery: ${quote.days?quote.days+' days after approval':'To be agreed'}\nTotal: ${money(quote.total)} USD\n\nASSUMPTIONS\n${quote.assumptions.join('\n')}\n\nSTATUS: ${quote.status==='paid'?'SANDBOX payment captured':quote.status==='demo-approved'?'DEMO approval only; no payment':'Draft — not approved'}\nAnalysis: ${quote.analysis}\nNot a signed contract; client identity is not verified in this build.\n`;const url=URL.createObjectURL(new Blob([text],{type:'text/plain;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='scopeguard-proposal.txt';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)};
$('example').onclick=()=>{$('project').value='여름 신제품 홍보 영상';$('client').value='블룸 스튜디오';$('brief').value='여름 신제품 홍보용 60초 영상 1개를 만들어 주세요. 화면 비율은 16:9로 하고 영어 자막과 배경음악을 넣어주세요. 납기는 7일이고 수정 2회 포함입니다.';toast('한국어 예시를 넣었어요. Generate 버튼을 눌러보세요.')};
$('reset').onclick=()=>{if(!confirm('Reset this browser’s current proposal and change order?'))return;quote=null;change=null;persist();render();toast('Project reset.')};
async function refreshProjects(){if(!server)return;try{const r=await fetch('/api/projects');if(!r.ok)return;const d=await r.json();const sel=$('projects');sel.replaceChildren(node('option','Saved proposals'));sel.firstChild.value='';for(const q of d.quotes){const opt=node('option',q.project+' · '+money(q.total));opt.value=q.id;sel.append(opt)}}catch{}}
$('projects').onchange=async()=>{if(!$('projects').value)return;try{const d=await api('/api/restore',{quoteId:$('projects').value});quote=d.quote;change=d.change;fillFields();persist();render()}catch(e){toast(e.message)}};
function fillFields(){if(!quote)return;$('project').value=quote.project;$('client').value=quote.client;$('brief').value=quote.brief;for(const [key,id] of [['base','base-rate'],['captions','caption-rate'],['music','music-rate']])$(id).value=quote.rates[key]/100;if(change)$('change').value=change.request;}
function renderConnections(){
 const c=connectionConfig||{};const rules=analysisMode()==='rules';const provider=c.aiProvider==='gemini'?'Gemini':'OpenAI';
 $('mode').textContent=rules?(server?'● Rule-based demo':'● Local demo'):(aiReady?(aiState==='response verified'?'● AI response verified':aiState==='configured'?'● AI configured':'● AI needs attention'):'● AI connection needed');
 $('connections').hidden=!connectionConfig;$('connections').textContent='Server: '+(c.server?'online':'offline')+' · Storage: '+(c.storage?'connected':'pending')+' · '+provider+': '+(c.ai?aiState:'key needed')+' · PayPal Sandbox: '+(c.paypal?paypalState:'credentials needed');
 $('ai-option').textContent='AI analysis · '+provider;
 const payment=live?' Payments use PayPal Sandbox test accounts only.':' Approvals are demos; no payment is created.';
 if(rules){
  $('notice-title').textContent='Rule-based demo · no AI calls';
  $('notice-detail').textContent='Generate quotes and compare changes using built-in rules.'+payment+(c.local?' Proposals are saved on this computer.':server?' Proposals are saved to your signed-in workspace.':' Results stay in this browser.');
 }else{
  $('notice-title').textContent=aiError?'AI needs attention':!aiReady?'AI connection needed':aiState==='response verified'?'AI response verified this session':provider+' configured · response not yet verified';
  $('notice-detail').textContent=(aiError?'The last AI request did not complete. Your input is preserved. ':aiState==='response verified'?'AI analysis succeeded in this session. Review every proposal before approving. ':'Generate a proposal to check the AI response. ')+(provider==='Gemini'?'Use fictional briefs without personal or confidential details. ':'')+payment;
 }
 $('analysis-hint').textContent=rules?'Built-in rules make no requests to an AI provider.':'Your brief is sent to '+provider+' for analysis. Review its interpretation before approving.';
 $('service-error').hidden=rules||!aiError;
 if(aiError){
  $('service-message').textContent=aiError.message;
  const help=$('service-help');const billing=['ai_credits_exhausted','ai_quota_exhausted'].includes(aiError.code);const limits=aiError.code==='ai_spend_limit';
  help.hidden=!(billing||limits);if(billing||limits){help.href='https://platform.openai.com/settings/organization/'+(limits?'limits':'billing');help.textContent=limits?'OpenAI API limits →':'OpenAI API billing →';}
 }
}
function showError(error){
 toast(error.message);if(!error.code?.startsWith('ai_'))return;
 aiError={message:error.message,code:error.code};aiState=error.code==='ai_credits_exhausted'?'credits needed':error.code==='ai_rate_limit'?'temporarily limited':'needs attention';renderConnections();
}
async function init(){try{const r=await fetch('/api/config');if(r.ok){const c=await r.json();server=!!c.server&&c.authenticated&&c.storage;live=!!c.paypal&&server;aiReady=!!c.ai&&server;
connectionConfig=c;renderConnections();
}}catch{}
try{const saved=JSON.parse(localStorage.getItem('scopeguard-v1'));if(saved?.quote){if(server){try{const d=await api('/api/restore',{quoteId:saved.quote.id});quote=d.quote;change=d.change}catch{quote=null;change=null}}else if(Array.isArray(saved.quote.items)&&Array.isArray(saved.quote.assumptions)){quote=saved.quote;change=saved.change;if(quote.status==='paid')quote.status='demo-approved';}fillFields()}}catch{quote=null;change=null}
const query=new URLSearchParams(location.search);if(live&&query.has('token')&&query.has('quote')&&query.has('order')){try{const d=await api('/api/capture',{orderKey:query.get('order'),orderId:query.get('token'),quoteId:query.get('quote')});quote=d.quote;change=d.change||null;fillFields();persist();history.replaceState({},'',location.pathname);paypalState='capture verified';renderConnections();toast('PayPal Sandbox payment captured.')}catch(e){showError(e)}}
if(query.has('cancel')){history.replaceState({},'',location.pathname);toast('Sandbox checkout canceled. No new capture was requested.')}render();await refreshProjects();}
init();
