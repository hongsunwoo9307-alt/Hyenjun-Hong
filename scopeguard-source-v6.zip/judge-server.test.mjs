import test from 'node:test';
import assert from 'node:assert/strict';
import { request } from 'node:http';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { createJudgeServer } from './scripts/judge-server.mjs';

function call(app, path, { body, headers = {}, method = body === undefined ? 'GET' : 'POST' } = {}) {
  return new Promise((accept, reject) => {
    const data = body === undefined ? undefined : JSON.stringify(body);
    const req = request(app.url + path, { method, headers: { ...(data ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } : {}), ...headers } }, res => {
      const chunks = [];
      res.on('data', chunk => chunks.push(chunk));
      res.on('end', () => {
        const text = Buffer.concat(chunks).toString();
        let json;
        try { json = JSON.parse(text); } catch {}
        accept({ status: res.statusCode, headers: res.headers, text, json });
      });
    });
    req.on('error', reject);
    req.end(data);
  });
}
const sample = { analysisMode: 'rules', project: 'Local judge example', client: 'Fictional studio', brief: 'One 60-second video with English captions, background music, 16:9, 7 days and two revisions.', rates: { base: 350, captions: 50, music: 50 } };

test('judge runner restricts Host and browser origins and never serves secrets or arbitrary source paths', async t => {
  const app = await createJudgeServer({ port: 0, databasePath: ':memory:', env: {} });
  t.after(() => app.close());
  assert.equal(app.server.address().address, '127.0.0.1');
  assert.equal((await call(app, '/')).status, 200);
  assert.match((await call(app, '/app.js')).headers['content-type'], /javascript/);
  for (const path of ['/.env.local', '/.git/config', '/lib/api.mjs', '/server.mjs', '/.local/scopeguard.sqlite', '/%2e%2e/.env.local', '/public/../.env.local', '/api/private/config']) {
    assert.equal((await call(app, path)).status, 404, path);
  }
  const port = new URL(app.url).port;
  for (const host of ['attacker.example', `127.0.0.1.evil:${port}`, `localhost:${Number(port) + 1}`, `localhost.:${port}`]) {
    assert.equal((await call(app, '/api/config', { headers: { Host: host } })).status, 403, host);
  }
  assert.equal((await call(app, '/api/config', { headers: { Host: `localhost:${port}`, Origin: `http://localhost:${port}` } })).status, 200);
  for (const headers of [{ Origin: 'https://attacker.example' }, { Origin: 'null' }, { Origin: `http://localhost:${port}` }, { 'Sec-Fetch-Site': 'cross-site' }, { 'Sec-Fetch-Site': 'same-site' }]) {
    assert.equal((await call(app, '/api/projects', { headers })).status, 403);
    assert.equal((await call(app, '/api/quote', { headers, body: sample })).status, 403);
  }
  const navigation = { 'Sec-Fetch-Site': 'cross-site', 'Sec-Fetch-Mode': 'navigate', 'Sec-Fetch-Dest': 'document' };
  assert.equal((await call(app, '/?quote=example&order=example&token=example', { headers: navigation })).status, 200);
  assert.equal((await call(app, '/api/projects', { headers: navigation })).status, 403);
  assert.equal((await call(app, '/app.js', { headers: navigation })).status, 403);
  assert.equal((await call(app, '/', { headers: { ...navigation, Origin: 'https://www.sandbox.paypal.com' } })).status, 403);
  assert.equal((await call(app, '/api/quote', { body: { ...sample, brief: 'x'.repeat(70000) } })).status, 413);
  assert.equal((await call(app, '/api/config', { body: {} })).status, 405);
  const config = await call(app, '/api/config');
  assert.equal(config.json.local, true);
  assert.equal(config.json.aiProvider, 'gemini');
  assert.equal(config.json.ai, false);
  assert.equal(config.json.paypal, false);
  assert.equal(config.json.authenticated, true);
  assert.equal(config.json.providersVerified, false);
  assert.deepEqual((await call(app, '/api/projects')).json.quotes, []);
});

test('judge runner persists the rules/demo/change flow across restarts and ignores incoming identities', async t => {
  const folder = mkdtempSync(join(tmpdir(), 'scopeguard-judge-'));
  const databasePath = join(folder, 'workspace.sqlite');
  let app;
  t.after(async () => { if (app) await app.close(); rmSync(folder, { recursive: true, force: true }); });
  let calls = 0;
  t.mock.method(globalThis, 'fetch', () => { calls++; throw new Error('Rules mode must not call a provider.'); });
  app = await createJudgeServer({ port: 0, databasePath, env: { GEMINI_API_KEY: 'test-only-not-a-real-key', OPENAI_API_KEY: 'test-only-not-a-real-key' } });
  const config = await call(app, '/api/config');
  assert.equal(config.json.ai, true);
  assert.doesNotMatch(config.text, /test-only-not-a-real-key/);
  const q = await call(app, '/api/quote', { body: sample, headers: { 'oai-authenticated-user-id': 'attacker-alice', Authorization: 'Bearer ignored' } });
  assert.equal(q.status, 200);
  assert.equal(q.json.total, 45000);
  assert.equal(q.json.analysis, 'demo-rules');
  assert.equal((await call(app, '/api/demo-approve', { body: { quoteId: q.json.id } })).json.status, 'demo-approved');
  const c = await call(app, '/api/change', { body: { quoteId: q.json.id, text: 'Please add 9:16 and Korean subtitles by tomorrow', analysisMode: 'rules' } });
  assert.equal(c.status, 200);
  assert.equal(c.json.total, 24250);
  assert.equal((await call(app, '/api/demo-change', { body: { changeId: c.json.id } })).json.status, 'demo-approved');
  assert.equal((await call(app, '/api/orders', { body: { quoteId: q.json.id, kind: 'base' } })).status, 503);
  await app.close();
  app = await createJudgeServer({ port: 0, databasePath, env: {} });
  const saved = await call(app, '/api/restore', { body: { quoteId: q.json.id }, headers: { 'oai-authenticated-user-id': 'attacker-bob' } });
  assert.equal(saved.json.quote.status, 'demo-approved');
  assert.equal(saved.json.change.status, 'demo-approved');
  assert.equal(saved.json.change.total, 24250);
  assert.equal((await call(app, '/api/projects')).json.quotes[0].id, q.json.id);
  assert.equal(calls, 0);
  const sql = new DatabaseSync(databasePath);
  try {
    assert.deepEqual(sql.prepare('SELECT DISTINCT owner FROM scopeguard_records').all().map(x => x.owner), ['scopeguard-local-judge']);
    assert.equal(sql.prepare('SELECT COUNT(*) AS n FROM scopeguard_local_migrations').get().n, 1);
  } finally { sql.close(); }
});
