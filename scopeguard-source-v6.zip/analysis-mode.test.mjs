import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { handle } from './lib/api.mjs';

const sample = {
  project: 'Explicit analysis mode',
  client: 'Sample client',
  brief: 'One 60-second video with English captions, background music, 16:9, 7 days and two revisions.',
  rates: { base: 350, captions: 50, music: 50 },
};
const changeText = 'Please add 9:16 and Korean subtitles by tomorrow';

function workspace() {
  const sql = new DatabaseSync(':memory:');
  sql.exec(readFileSync(new URL('./drizzle/0000_salty_ozymandias.sql', import.meta.url), 'utf8'));
  const DB = {
    prepare(text) {
      const stmt = sql.prepare(text);
      return { bind(...args) {
        return {
          first: async () => stmt.get(...args),
          all: async () => ({ results: stmt.all(...args) }),
          run: async () => stmt.run(...args),
        };
      } };
    },
  };
  const env = { DB };
  async function call(action, body) {
    const response = await handle(new Request('https://scopeguard.example/api/' + action, {
      method: body === undefined ? 'GET' : 'POST',
      headers: { 'oai-authenticated-user-id': 'alice', 'Content-Type': 'application/json' },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    }), env);
    return { status: response.status, data: await response.json() };
  }
  return { sql, env, call };
}

test('explicit rules mode saves quotes and changes without calling configured providers', async t => {
  const { sql, env, call } = workspace();
  env.OPENAI_API_KEY = 'mock-key';
  env.PAYPAL_CLIENT_ID = 'mock-client';
  env.PAYPAL_CLIENT_SECRET = 'mock-secret';
  let providerCalls = 0;
  t.mock.method(globalThis, 'fetch', async () => {
    providerCalls++;
    return Response.json({ error: { code: 'credit_balance_exhausted' } }, { status: 429 });
  });
  try {
    const generated = await call('quote', { ...sample, analysisMode: 'rules' });
    assert.equal(generated.status, 200);
    assert.equal(generated.data.analysis, 'demo-rules');
    assert.equal(generated.data.total, 45000);
    const quoteId = generated.data.id;
    assert.equal((await call('demo-approve', { quoteId })).data.status, 'demo-approved');

    const compared = await call('change', { quoteId, text: changeText, analysisMode: 'rules' });
    assert.equal(compared.status, 200);
    assert.equal(compared.data.analysis, 'demo-rules');
    assert.equal(compared.data.total, 24250);
    const restored = (await call('restore', { quoteId })).data;
    assert.equal(restored.quote.analysis, 'demo-rules');
    assert.equal(restored.quote.status, 'demo-approved');
    assert.equal(restored.change.analysis, 'demo-rules');
    assert.equal(restored.change.total, 24250);
    assert.equal(providerCalls, 0);
  } finally { sql.close(); }
});

test('explicit AI requires a key and invalid modes cannot silently select an analysis provider', async t => {
  const { sql, call } = workspace();
  let providerCalls = 0;
  t.mock.method(globalThis, 'fetch', () => {
    providerCalls++;
    throw new Error('Mode validation must happen before provider access');
  });
  try {
    const missingKey = await call('quote', { ...sample, analysisMode: 'ai' });
    assert.equal(missingKey.status, 503);
    assert.equal(missingKey.data.code, 'ai_not_configured');
    assert.equal((await call('quote', { ...sample, analysisMode: 'automatic' })).status, 400);
    assert.deepEqual((await call('projects')).data.quotes, []);

    const quoteId = (await call('quote', { ...sample, analysisMode: 'rules' })).data.id;
    await call('demo-approve', { quoteId });
    const missingChangeKey = await call('change', { quoteId, text: changeText, analysisMode: 'ai' });
    assert.equal(missingChangeKey.status, 503);
    assert.equal(missingChangeKey.data.code, 'ai_not_configured');
    assert.equal((await call('change', { quoteId, text: changeText, analysisMode: 'automatic' })).status, 400);
    assert.equal((await call('restore', { quoteId })).data.change, null);
    assert.equal(providerCalls, 0);
  } finally { sql.close(); }
});

test('omitting analysis mode preserves the existing rules-without-key and AI-with-key behavior', async t => {
  const { sql, env, call } = workspace();
  let providerCalls = 0;
  t.mock.method(globalThis, 'fetch', async url => {
    providerCalls++;
    assert.equal(url, 'https://api.openai.com/v1/chat/completions');
    return Response.json({ choices: [{ message: { content: JSON.stringify({
      duration: 60, days: 7, revisions: 2, aspect: '16:9', caption: true,
      music: true, languages: ['English'], assumptions: [],
    }) } }] });
  });
  try {
    const rules = await call('quote', sample);
    assert.equal(rules.status, 200);
    assert.equal(rules.data.analysis, 'demo-rules');
    assert.equal(providerCalls, 0);
    env.OPENAI_API_KEY = 'mock-key';
    const ai = await call('quote', sample);
    assert.equal(ai.status, 200);
    assert.equal(ai.data.analysis, 'openai');
    assert.equal(ai.data.total, 45000);
    assert.equal(providerCalls, 1);
  } finally { sql.close(); }
});

test('explicit AI billing failure never silently falls back to a saved rules quote', async t => {
  const { sql, env, call } = workspace();
  env.OPENAI_API_KEY = 'mock-key';
  t.mock.method(globalThis, 'fetch', async () =>
    Response.json({ error: { code: 'credit_balance_exhausted' } }, { status: 429 }));
  try {
    const result = await call('quote', { ...sample, analysisMode: 'ai' });
    assert.equal(result.status, 503);
    assert.equal(result.data.code, 'ai_credits_exhausted');
    assert.deepEqual((await call('projects')).data.quotes, []);
  } finally { sql.close(); }
});

test('rules quotes retain Sandbox order, capture and extra-order support without AI calls', async t => {
  const { sql, env, call } = workspace();
  env.OPENAI_API_KEY = 'mock-key';
  env.PAYPAL_CLIENT_ID = 'mock-client';
  env.PAYPAL_CLIENT_SECRET = 'mock-secret';
  let quoteId;
  const amounts = [];
  const visited = [];
  t.mock.method(globalThis, 'fetch', async (url, init) => {
    visited.push(url);
    assert.match(url, /^https:\/\/api-m\.sandbox\.paypal\.com\//);
    if (url.endsWith('/token')) return Response.json({ access_token: 'mock-token' });
    if (url.endsWith('/orders')) {
      const body = JSON.parse(init.body);
      amounts.push(body.purchase_units[0].amount.value);
      const id = 'SANDBOX-' + amounts.length;
      return Response.json({ id, links: [{ rel: 'payer-action', href: 'https://www.sandbox.paypal.com/checkoutnow?token=' + id }] });
    }
    assert.ok(url.endsWith('/SANDBOX-1/capture'));
    return Response.json({
      id: 'SANDBOX-1', status: 'COMPLETED',
      purchase_units: [{ reference_id: quoteId, payments: { captures: [{
        id: 'CAPTURE-1', status: 'COMPLETED', amount: { currency_code: 'USD', value: '450.00' },
      }] } }],
    });
  });
  try {
    const quote = await call('quote', { ...sample, analysisMode: 'rules' });
    assert.equal(quote.status, 200);
    quoteId = quote.data.id;
    assert.equal(visited.length, 0);
    const base = await call('orders', { quoteId, kind: 'base', total: 1 });
    assert.equal(base.status, 200);
    assert.equal(base.data.id, 'SANDBOX-1');
    const capture = await call('capture', { quoteId, orderKey: 'order:' + quoteId + ':base', orderId: base.data.id });
    assert.equal(capture.status, 200);
    assert.equal(capture.data.quote.status, 'paid');
    assert.equal(capture.data.quote.analysis, 'demo-rules');

    const change = await call('change', { quoteId, text: changeText, analysisMode: 'rules' });
    assert.equal(change.status, 200);
    const extra = await call('orders', { quoteId, kind: 'change', changeId: change.data.id });
    assert.equal(extra.status, 200);
    assert.equal(extra.data.id, 'SANDBOX-2');
    assert.deepEqual(amounts, ['450.00', '242.50']);
    assert.equal(visited.some(url => url.includes('api.openai.com')), false);
  } finally { sql.close(); }
});
