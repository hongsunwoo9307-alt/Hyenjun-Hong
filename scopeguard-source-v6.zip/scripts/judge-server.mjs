import { createServer } from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { handle } from '../lib/api.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
const localOwner = 'scopeguard-local-judge';
const bodyLimit = 64 * 1024;
const assets = new Map([
  ['/', ['index.html', 'text/html; charset=utf-8']],
  ['/index.html', ['index.html', 'text/html; charset=utf-8']],
  ['/app.js', ['app.js', 'text/javascript; charset=utf-8']],
  ['/domain.js', ['domain.js', 'text/javascript; charset=utf-8']],
  ['/style.css', ['style.css', 'text/css; charset=utf-8']],
]);
const apiActions = new Set(['config', 'projects', 'quote', 'demo-approve', 'change', 'demo-change', 'restore', 'orders', 'capture']);
const environmentKeys = ['AI_PROVIDER', 'GEMINI_API_KEY', 'GEMINI_MODEL', 'OPENAI_API_KEY', 'OPENAI_MODEL', 'PAYPAL_CLIENT_ID', 'PAYPAL_CLIENT_SECRET'];

function openDatabase(path) {
  if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true });
  const sql = new DatabaseSync(path);
  try {
    sql.exec('PRAGMA busy_timeout = 5000; CREATE TABLE IF NOT EXISTS scopeguard_local_migrations (name TEXT PRIMARY KEY NOT NULL)');
    const journal = JSON.parse(readFileSync(resolve(root, 'drizzle/meta/_journal.json'), 'utf8'));
    for (const entry of journal.entries) {
      if (!/^\d+_[a-zA-Z0-9_]+$/.test(entry.tag)) throw new Error('Invalid migration name');
      if (sql.prepare('SELECT name FROM scopeguard_local_migrations WHERE name = ?').get(entry.tag)) continue;
      const migration = readFileSync(resolve(root, 'drizzle', entry.tag + '.sql'), 'utf8');
      sql.exec('BEGIN IMMEDIATE');
      try {
        sql.exec(migration);
        sql.prepare('INSERT INTO scopeguard_local_migrations (name) VALUES (?)').run(entry.tag);
        sql.exec('COMMIT');
      } catch (error) {
        sql.exec('ROLLBACK');
        throw error;
      }
    }
    return {
      sql,
      DB: { prepare(text) {
        const statement = sql.prepare(text);
        return { bind(...values) { return {
          first: async () => statement.get(...values) ?? null,
          all: async () => ({ results: statement.all(...values) }),
          run: async () => statement.run(...values),
        }; } };
      } },
    };
  } catch (error) {
    sql.close();
    throw error;
  }
}

function send(response, status, body, type = 'application/json; charset=utf-8') {
  response.writeHead(status, {
    'Content-Type': type,
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Cross-Origin-Resource-Policy': 'same-origin',
    'Referrer-Policy': 'no-referrer',
  });
  response.end(body);
}

function fail(response, status, message) {
  send(response, status, JSON.stringify({ error: message }));
}

function readBody(request) {
  return new Promise((resolveBody, reject) => {
    let size = 0;
    let oversized = false;
    const chunks = [];
    request.on('data', chunk => {
      size += chunk.length;
      if (size > bodyLimit) {
        if (!oversized) {
          oversized = true;
          chunks.length = 0;
          reject(Object.assign(new Error('Request too large.'), { status: 413 }));
        }
      } else if (!oversized) chunks.push(chunk);
    });
    request.on('end', () => { if (!oversized) resolveBody(Buffer.concat(chunks)); });
    request.on('error', () => reject(new Error('Request interrupted.')));
  });
}

// The identity below is deliberately local-only. This adapter must never be exposed through a proxy or tunnel.
export async function createJudgeServer({ port = 3000, databasePath = resolve(root, '.local/scopeguard.sqlite'), env = process.env } = {}) {
  if (!Number.isInteger(port) || port < 0 || port > 65535) throw new Error('PORT must be an integer from 0 to 65535.');
  const { sql, DB } = openDatabase(databasePath);
  const runtime = { AI_PROVIDER: 'gemini', GEMINI_MODEL: 'gemini-3.5-flash-lite', DB };
  for (const key of environmentKeys) if (typeof env[key] === 'string' && env[key].trim()) runtime[key] = env[key];
  let actualPort;
  const server = createServer({ requestTimeout: 15000, headersTimeout: 10000 }, async (request, response) => {
    try {
      const host = request.headers.host;
      const hostCount = request.rawHeaders.filter((_, i) => i % 2 === 0 && request.rawHeaders[i].toLowerCase() === 'host').length;
      if (request.socket.remoteAddress !== '127.0.0.1' || hostCount !== 1 || ![`127.0.0.1:${actualPort}`, `localhost:${actualPort}`].includes(host)) {
        return fail(response, 403, 'This judge workspace is available only on its loopback address.');
      }
      const origin = `http://${host}`;
      if (request.headers.origin !== undefined && request.headers.origin !== origin) return fail(response, 403, 'Cross-origin request rejected.');
      const target = request.url || '';
      if (!target.startsWith('/') || target.startsWith('//')) return fail(response, 400, 'Invalid request target.');
      const path = target.split('?')[0];
      const fetchSite = request.headers['sec-fetch-site'];
      // PayPal can navigate back to the document; all API requests still require same-origin context.
      const returnNavigation = request.method === 'GET' && path === '/' && request.headers.origin === undefined
        && request.headers['sec-fetch-mode'] === 'navigate' && request.headers['sec-fetch-dest'] === 'document';
      if (fetchSite !== undefined && !['same-origin', 'none'].includes(fetchSite) && !returnNavigation) return fail(response, 403, 'Cross-site request rejected.');
      const asset = assets.get(path);
      if (asset) {
        if (!['GET', 'HEAD'].includes(request.method)) return fail(response, 405, 'Method not allowed.');
        return send(response, 200, request.method === 'HEAD' ? undefined : readFileSync(resolve(root, 'public', asset[0])), asset[1]);
      }
      const action = path.startsWith('/api/') ? path.slice(5) : '';
      if (!apiActions.has(action)) return fail(response, 404, 'Not found.');
      const expectedMethod = ['config', 'projects'].includes(action) ? 'GET' : 'POST';
      if (request.method !== expectedMethod) return fail(response, 405, 'Method not allowed.');
      if (Number(request.headers['content-length'] || 0) > bodyLimit) return fail(response, 413, 'Request too large.');
      const body = request.method === 'POST' ? await readBody(request) : undefined;
      // Never forward client identity, proxy, authorization or cookie headers.
      const headers = new Headers({ 'oai-authenticated-user-id': localOwner });
      if (request.headers['content-type']) headers.set('Content-Type', request.headers['content-type']);
      if (request.headers.origin) headers.set('Origin', request.headers.origin);
      const apiRequest = new Request(origin + target, { method: request.method, headers, ...(body === undefined ? {} : { body }) });
      const result = await handle(apiRequest, runtime);
      if (action === 'config' && result.ok) return send(response, result.status, JSON.stringify({ ...await result.json(), local: true }));
      return send(response, result.status, Buffer.from(await result.arrayBuffer()));
    } catch (error) {
      if (!response.headersSent) fail(response, error.status === 413 ? 413 : 500, error.status === 413 ? 'Request too large.' : 'The local request could not be completed.');
      else response.end();
    }
  });
  try {
    await new Promise((accept, reject) => {
      server.once('error', reject);
      server.listen(port, '127.0.0.1', () => { server.removeListener('error', reject); accept(); });
    });
  } catch (error) {
    sql.close();
    throw error;
  }
  actualPort = server.address().port;
  let closing;
  return {
    server,
    url: `http://127.0.0.1:${actualPort}`,
    close() {
      closing ??= new Promise((accept, reject) => server.close(error => {
        sql.close();
        error ? reject(error) : accept();
      }));
      return closing;
    },
  };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const app = await createJudgeServer({ port: Number(process.env.PORT || 3000) });
    console.log(`ScopeGuard local judge workspace: ${app.url}`);
    console.log('Local-only data. Rules mode works without keys; approvals are demos unless Sandbox credentials are configured.');
    for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, () => app.close().then(() => process.exit(0)));
  } catch (error) {
    console.error(error.code === 'EADDRINUSE' ? 'The local port is in use. Choose another PORT and retry.' : 'Could not start ScopeGuard. Use Node.js 24+, a valid PORT, and a writable .local directory.');
    process.exitCode = 1;
  }
}
