import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { handle } from './lib/api.mjs';

const sample={project:'Hosted test',client:'Sample client',brief:'One 60-second video with English captions, background music, 16:9, 7 days and two revisions.',rates:{base:350,captions:50,music:50}};
function workspace(){
  const sql=new DatabaseSync(':memory:');
  sql.exec(readFileSync(new URL('./drizzle/0000_salty_ozymandias.sql',import.meta.url),'utf8'));
  const DB={prepare(text){const stmt=sql.prepare(text);return {bind(...args){return {first:async()=>stmt.get(...args),all:async()=>({results:stmt.all(...args)}),run:async()=>stmt.run(...args)}}}}};
  const env={DB};
  async function call(action,body,owner='alice',headers={}){
    const req=new Request('https://scopeguard.example/api/'+action,{method:body===undefined?'GET':'POST',headers:{...(owner?{'oai-authenticated-user-id':owner}:{}),'Content-Type':'application/json',...headers},...(body===undefined?{}:{body:JSON.stringify(body)})});
    const r=await handle(req,env);return {status:r.status,data:await r.json()};
  }
  return {sql,env,call};
}
test('hosted configuration is honest and saved records require identity',async()=>{
  const {sql,call}=workspace();try{
    const c=await call('config',undefined,null);assert.equal(c.data.ai,false);assert.equal(c.data.paypal,false);assert.equal(c.data.storage,true);assert.equal(c.data.authenticated,false);
    assert.equal((await call('projects',undefined,null)).status,401);
    assert.equal((await call('quote',sample,'alice',{Origin:'https://elsewhere.example'})).status,403);
  }finally{sql.close()}
});
test('D1 records restore, stay owner-scoped and distinguish demo approval from payment',async()=>{
  const {sql,call}=workspace();try{
    const {data:q,status}=await call('quote',sample);assert.equal(status,200);assert.equal(q.total,45000);
    assert.equal((await call('restore',{quoteId:q.id},'bob')).status,404);
    assert.equal((await call('demo-approve',{quoteId:q.id},'bob')).status,404);
    assert.deepEqual((await call('projects',undefined,'bob')).data.quotes,[]);
    assert.equal((await call('change',{quoteId:q.id,text:'Add 9:16'})).status,400);
    const approved=await call('demo-approve',{quoteId:q.id});assert.equal(approved.data.status,'demo-approved');
    const c=await call('change',{quoteId:q.id,text:'Please add 9:16 and Korean subtitles by tomorrow'});assert.equal(c.data.total,24250);
    await call('demo-change',{changeId:c.data.id});
    const restored=await call('restore',{quoteId:q.id});assert.equal(restored.data.change.status,'demo-approved');assert.equal(restored.data.quote.status,'demo-approved');
    assert.equal((await call('orders',{quoteId:q.id,kind:'base'})).status,503);
  }finally{sql.close()}
});
test('sandbox orders ignore client prices, retry idempotently, validate capture and prevent demo downgrade',async t=>{
  const {sql,env,call}=workspace();env.PAYPAL_CLIENT_ID='test';env.PAYPAL_CLIENT_SECRET='test';
  let orderCalls=0,captureCalls=0,quoteId,orderKey,createBody;let valid=false;
  t.mock.method(globalThis,'fetch',async(url,init)=>{
    assert.match(url,/^https:\/\/api-m\.sandbox\.paypal\.com\//);
    if(url.endsWith('/token'))return Response.json({access_token:'test-token'});
    if(url.endsWith('/orders')){orderCalls++;createBody=JSON.parse(init.body);assert.ok(init.headers['PayPal-Request-Id']);return Response.json({id:'PAYPAL-TEST',links:[{rel:'payer-action',href:'https://www.sandbox.paypal.com/checkoutnow?token=PAYPAL-TEST'}]})}
    if(init.method==='GET')return Response.json({id:'PAYPAL-TEST',status:'CREATED',purchase_units:[{reference_id:quoteId,amount:{currency_code:'USD',value:'450.00'}}]});
    captureCalls++;return Response.json({id:'PAYPAL-TEST',status:'COMPLETED',purchase_units:[{reference_id:quoteId,payments:{captures:[{id:'CAPTURE-TEST',status:'COMPLETED',amount:{currency_code:'USD',value:valid?'450.00':'1.00'}}]}}]});
  });
  try{
    const q=(await call('quote',sample)).data;quoteId=q.id;orderKey='order:'+q.id+':base';
    await call('orders',{quoteId,kind:'base',total:1});await call('orders',{quoteId,kind:'base'});assert.equal(orderCalls,1);assert.equal(createBody.purchase_units[0].amount.value,'450.00');
    const payload={quoteId,orderKey,orderId:'PAYPAL-TEST'};
    assert.equal((await call('capture',payload,'bob')).status,404);
    assert.equal((await call('capture',payload)).status,409);assert.equal((await call('restore',{quoteId})).data.quote.status,'draft');
    valid=true;assert.equal((await call('capture',payload)).data.quote.status,'paid');await call('capture',payload);assert.equal(captureCalls,2);
    assert.equal((await call('demo-approve',{quoteId})).status,409);
  }finally{sql.close()}
});

test('configured credentials do not claim verified provider responses',async t=>{
 const {sql,env,call}=workspace();env.OPENAI_API_KEY='test';env.PAYPAL_CLIENT_ID='test';env.PAYPAL_CLIENT_SECRET='test';
 t.mock.method(globalThis,'fetch',()=>{throw new Error('Config must not spend API credits')});
 try{const {data}=await call('config');assert.equal(data.configured,true);assert.equal(data.providersVerified,false);assert.equal(data.ready,undefined)}
 finally{sql.close()}
});

test('AI failures distinguish billing from rate limiting without saving a false proposal or exposing provider details',async t=>{
 const {sql,env,call}=workspace();env.OPENAI_API_KEY='test';let response,calls=0;
 t.mock.method(globalThis,'fetch',async()=>{calls++;return response()});
 const failures=[
  [429,{code:'credit_balance_exhausted',type:'insufficient_quota'},'ai_credits_exhausted',/balance is empty/],
  [429,{code:'project_spend_limit_exceeded'},'ai_spend_limit',/spending or usage limit/],
  [429,{type:'insufficient_quota'},'ai_quota_exhausted',/balance and spending limits/],
  [429,{code:'rate_limit_exceeded'},'ai_rate_limit',/Wait a moment/],
  [401,{code:'invalid_api_key'},'ai_authentication',/authenticate/],
  [404,{code:'model_not_found'},'ai_model_access',/access this model/],
  [500,{},'ai_unavailable',/retry later/]
 ];
 try{
  for(const [status,error,code,message] of failures){
   response=()=>Response.json({error:{...error,message:'PRIVATE_PROVIDER_DETAIL'}},{status});
   const result=await call('quote',sample);assert.ok(result.status>=500);assert.equal(result.data.code,code);assert.match(result.data.error,message);
   assert.doesNotMatch(JSON.stringify(result.data),/PRIVATE_PROVIDER_DETAIL/);
   assert.deepEqual((await call('projects')).data.quotes,[]);
  }
  assert.equal(calls,failures.length);
  response=()=>new Response('upstream unavailable',{status:502});
  assert.equal((await call('quote',sample)).data.code,'ai_unavailable');
  response=()=>{throw new Error('private network detail')};
  assert.equal((await call('quote',sample)).data.code,'ai_unavailable');
 }finally{sql.close()}
});

test('an AI change failure preserves the approved quote, and recovery saves a real AI result',async t=>{
 const {sql,env,call}=workspace();let failure=true;
 t.mock.method(globalThis,'fetch',async()=>failure
  ?Response.json({error:{code:'credit_balance_exhausted'}},{status:429})
  :Response.json({choices:[{message:{content:JSON.stringify({duration:60,days:7,revisions:2,aspect:'16:9',caption:true,music:true,languages:['English'],assumptions:[]})}}]}));
 try{
  const q=(await call('quote',sample)).data;await call('demo-approve',{quoteId:q.id});env.OPENAI_API_KEY='test';
  const change=await call('change',{quoteId:q.id,text:'Add 9:16'});assert.equal(change.data.code,'ai_credits_exhausted');
  const saved=(await call('restore',{quoteId:q.id})).data;assert.equal(saved.quote.status,'demo-approved');assert.equal(saved.change,null);
  failure=false;const generated=await call('quote',sample);assert.equal(generated.status,200);assert.equal(generated.data.analysis,'openai');assert.equal(generated.data.total,45000);
  assert.equal((await call('restore',{quoteId:generated.data.id})).data.quote.analysis,'openai');
 }finally{sql.close()}
});

test('cached Sandbox checkout checks expiry, uncertain failures and prior payment without creating another order',async t=>{
 const f=workspace();f.env.PAYPAL_CLIENT_ID='test';f.env.PAYPAL_CLIENT_SECRET='test';let state='CREATED',quoteId,creates=0;
 t.mock.method(globalThis,'fetch',async(url,init)=>{
  if(url.endsWith('/token'))return Response.json({access_token:'test'});
  if(init.method==='GET'){
   assert.equal(init.body,undefined);assert.equal(init.headers['PayPal-Request-Id'],undefined);
   if(state==='NOT_FOUND')return Response.json({name:'RESOURCE_NOT_FOUND'},{status:404});
   if(state==='TRANSIENT')return Response.json({name:'INTERNAL_SERVER_ERROR'},{status:500});
   return Response.json({id:'P-CACHED',status:state,purchase_units:[{reference_id:quoteId,amount:{currency_code:'USD',value:state==='MISMATCH'?'1.00':'450.00'},payments:{captures:[{id:'C-CACHED',status:'COMPLETED',amount:{currency_code:'USD',value:'450.00'}}]}}]});
  }
  assert.ok(url.endsWith('/orders'));creates++;return Response.json({id:'P-CACHED',links:[{rel:'payer-action',href:'https://www.sandbox.paypal.com/checkoutnow?token=P-CACHED'}]});
 });
 try{
  quoteId=(await f.call('quote',sample)).data.id;const b={quoteId,kind:'base'};
  assert.equal((await f.call('orders',b)).status,200);
  assert.match((await f.call('orders',b)).data.approvalUrl,/www.sandbox.paypal.com/);
  for(state of ['VOIDED','NOT_FOUND']){const r=await f.call('orders',b);assert.equal(r.status,409);assert.equal(r.data.code,'paypal_order_expired')}
  state='TRANSIENT';assert.equal((await f.call('orders',b)).status,502);assert.equal((await f.call('restore',{quoteId})).data.quote.status,'draft');
  state='MISMATCH';assert.equal((await f.call('orders',b)).data.code,'paypal_order_mismatch');
  state='APPROVED';assert.match((await f.call('orders',b)).data.approvalUrl,/^https:\/\/scopeguard.example\/\?quote=/);assert.equal((await f.call('restore',{quoteId})).data.quote.status,'draft');
  state='COMPLETED';assert.equal((await f.call('orders',b)).status,200);assert.equal((await f.call('restore',{quoteId})).data.quote.status,'paid');
  assert.equal(creates,1);assert.equal((await f.call('orders',b)).status,409);
 }finally{f.sql.close()}
});
