# ScopeGuard

Turn creative briefs into clear quotes. Agree on the extras before they become unpaid work.

ScopeGuard helps freelance video creators extract deliverables from an English or Korean brief, review a quote, pay with PayPal Sandbox, and price later scope changes separately. Gemini interprets scope; the server calculates all prices in integer cents from the creator's rate card. Real-money payments are not supported.

## Run locally — Node.js 24 or later

Download or clone this repository, open a terminal in it, and run:

```sh
node scripts/judge-server.mjs
```

Open **http://127.0.0.1:3000**. No npm installation, build, ChatGPT login, or API key is needed for the explicitly labeled rules/demo flow. Proposals persist in `.local/scopeguard.sqlite` and remain after restarting. Stop the server with Ctrl+C. Use the same address consistently so browser storage and callbacks share an origin.

1. Keep **Rule-based demo**, use the fictional sample brief, and generate a **$450** quote.
2. Review the scope, check approval, and choose **Approve in demo mode**. The app labels it **DEMO APPROVED**; no payment is made.
3. Compare the sample extra request: a 9:16 version, Korean captions, and delivery tomorrow. Expected extra fee: **$242.50**.
4. Approve the extra in demo mode, reload, and restore it from **Saved proposals**. Download the base proposal if desired.

The judge server shares `lib/api.mjs` and the frontend with the hosted app. Its single local workspace is intentionally limited to 127.0.0.1. It rejects foreign Host/Origin headers and cross-site API requests, ignores caller-supplied identity headers, and serves only the public application assets. **Do not tunnel, reverse-proxy, or expose this local runner on a network.** The hosted application uses the Sites identity gateway and user-scoped D1 storage instead.

## Enable real Gemini analysis

Create an untracked `.env.local` in the repository root using your own Google AI Studio key:

```dotenv
AI_PROVIDER=gemini
GEMINI_MODEL=gemini-3.5-flash-lite
GEMINI_API_KEY=replace-with-your-own-key
```

Restart with:

```sh
node --env-file-if-exists=.env.local scripts/judge-server.mjs
```

Select **AI analysis · Gemini**, then generate a proposal. A successful current request shows **AI response verified** and **Analyzed with Gemini**. Configuration alone does not imply verification. Invalid or failed AI responses never silently become rules results. With PayPal unset, you can use explicit demo approval and then compare extra requests with real Gemini.

Use fictional briefs without personal or confidential details. Gemini free-tier availability and quotas are controlled by Google; this app never enables billing. Requests use the Interactions REST API with structured JSON, `store:false`, and validated output. Only relevant brief/scope details are sent. The server retains control of prices. The selected model supports free-tier use; check current [Google pricing](https://ai.google.dev/gemini-api/docs/pricing) and terms. Legacy OpenAI support is opt-in through `AI_PROVIDER=openai`; Gemini never falls back to an OpenAI key.

## Enable PayPal Sandbox

Add your Sandbox business application's credentials to `.env.local`:

```dotenv
PAYPAL_CLIENT_ID=replace-with-your-sandbox-client-id
PAYPAL_CLIENT_SECRET=replace-with-your-sandbox-client-secret
```

Restart the command above. Use a separate Sandbox **personal buyer**, never a real account. Review a new proposal and open PayPal Sandbox. After buyer approval, the return to the same local origin triggers capture. The app displays **SANDBOX PAID** only after the server validates the order, proposal reference, USD currency, exact amount and completed capture. Base and extra work have separate orders. Saved request identifiers protect retries, and reused checkout links are checked for expiry or prior completion.

PayPal requests use `api-m.sandbox.paypal.com` exclusively. If checkout fails, preserve the error and keep the proposal unpaid; do not change database payment states. Country combinations and Sandbox account availability depend on PayPal. No secret, buyer password, or API key belongs in the public repository or recording.

## Fictional demonstration scenario

Base brief:

> We need one 60-second product video for our summer launch. Please include English captions and background music. Deliver in 16:9 within 7 days. Two rounds of revisions included.

Rates: video $350, captions $50, music selection $50. Total: **$450**.

Extra request:

> Could you also make a 9:16 version, add Korean subtitles, and deliver it tomorrow?

Expected additions: format $105, captions $50, rush $87.50; total **$242.50**. Rates are illustrative, not market estimates. Music licensing, taxes and third-party charges are excluded. Review all AI interpretation. Separate client identities and legally binding signatures are not implemented.

## Verification and current limits

- Real hosted English and Korean Gemini quote generation and persistence succeeded on 10 November 2026, each totaling $450.
- Real Gemini quote and extra-request comparison succeeded in an isolated SQLite workspace on 11 November: $450 and $242.50. That run used explicit demo approval and did **not** test PayPal capture.
- Real Sandbox order creation succeeded. End-to-end buyer approval and base/change captures are still awaiting verification; do not describe them as completed.
- The automated suite covers rules, AI schema validation, errors, owner isolation, persistence, cents arithmetic, idempotency, capture validation, and local-runner access boundaries. Provider responses in this suite are mocked.

Run the complete tests with Node.js 24:

```sh
node --test test.mjs hosted.test.mjs ui.test.mjs analysis-mode.test.mjs gemini.test.mjs judge-server.test.mjs
```

## Hosted development

The hosted build uses Vinext, Cloudflare Workers and D1. Its current deployment is owner-private. The local judge runner above provides the independent setup route.

```sh
npm install
npm run build
npm run dev
```

Hosting configuration is in `.openai/hosting.json`. Store provider credentials as server-only Sites runtime variables and deploy to apply them. Keep the gateway's authenticated identity trusted only in the intended hosting environment. `server.mjs` is an older prototype retained for regression coverage, not the current hosted backend or judge runner.

## License and disclosure

MIT — see [LICENSE](LICENSE). Developed with AI assistance from Codex. This repository describes a hackathon prototype; competition registration and final submission are tracked separately.
