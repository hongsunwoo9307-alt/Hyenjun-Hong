import { sqliteTable, text, integer, index } from 'drizzle-orm/sqlite-core';
export const records = sqliteTable('scopeguard_records', {
 id: text('id').primaryKey(), owner: text('owner').notNull(), kind: text('kind').notNull(),
 payload: text('payload').notNull(), updatedAt: integer('updated_at').notNull(),
}, table => [index('scopeguard_owner_kind').on(table.owner, table.kind)]);
