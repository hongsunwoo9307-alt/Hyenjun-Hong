import { env } from 'cloudflare:workers';
import { handle } from '../../../lib/api.mjs';
export const dynamic = 'force-dynamic';
export async function GET(req:Request){return handle(req,env)}
export async function POST(req:Request){return handle(req,env)}
