import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'ScopeGuard — Clear scope. Confident payments.', description: 'Review creative scope, approve change orders and pay through PayPal Sandbox.' };
export default function Layout({children}: {children: React.ReactNode}) {return <html lang="en"><body>{children}</body></html>;}
